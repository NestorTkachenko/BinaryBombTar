CS 61 Problem Set 2
===================

This is bomb #244.

It belongs to NuffNuff (nestortkachenko@college.harvard.edu).
